package com.example.lpcouts;

public class HOHAccount extends User {

  //Create Aa HOHAccount instant using the User class
  public HOHAccount(String paramString1, String paramString2, String paramString3) {
    super(paramString1, paramString2, paramString3, null);
  }
}
