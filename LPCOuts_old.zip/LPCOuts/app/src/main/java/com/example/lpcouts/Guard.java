package com.example.lpcouts;

public class Guard extends User {

    //Creates a Guard instance by reference to User class
    public Guard(String paramString1, String paramString2) {
        super(paramString1, paramString2, null, null);
    }
}
