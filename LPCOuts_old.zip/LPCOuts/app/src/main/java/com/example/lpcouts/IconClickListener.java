package com.example.lpcouts;

public interface IconClickListener {
  void onGuardClick();
  
  void onHOHClick();
  
  void onStudentClick();
}
