package com.example.lpcouts;

public interface CreationInProgress {
    void onCreationInProgress();
}
